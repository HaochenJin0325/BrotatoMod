extends "res://ui/menus/run/character_selection.gd"

const HeroEditorRules = preload("res://mods-unpacked/BrotatoMod-HeroEditor/hero_editor_rules.gd")

var _hero_editor_dialog: ConfirmationDialog
var _hero_editor_first: OptionButton
var _hero_editor_second: OptionButton
var _hero_editor_parent_options: Array = []
var _hero_editor_pending_player: int = -1
var _hero_editor_first_preview: Dictionary = {}
var _hero_editor_second_preview: Dictionary = {}
var _hero_editor_fusion_preview: Dictionary = {}


func _get_all_possible_elements(player_index: int) -> Array:
	var elements: Array = ._get_all_possible_elements(player_index)
	var editor_row: CharacterData = HeroEditorRules.make_editor_row()
	if editor_row != null:
		elements.push_back(editor_row)
	return elements


func _get_unlocked_elements(player_index: int) -> Array:
	var unlocked: Array = ._get_unlocked_elements(player_index).duplicate()
	var editor_hash: int = Keys.generate_hash("character_hero_editor")
	if not unlocked.has(editor_hash):
		unlocked.push_back(editor_hash)
	return unlocked


func _on_element_pressed(element: InventoryElement, inventory_player_index: int) -> void:
	var player_index: int = FocusEmulatorSignal.get_player_index(element)
	if player_index < 0:
		return

	if element.item is CharacterData and HeroEditorRules.is_editor_row(element.item):
		_open_hero_editor_dialog(player_index)
		return

	if element.is_random:
		var available_elements: Array = []
		for candidate in displayed_elements[0]:
			if candidate is CharacterData and HeroEditorRules.is_editor_row(candidate):
				continue
			if not candidate.is_locked and _get_item_disabled_update(candidate) == null:
				available_elements.push_back(candidate)
		_player_characters[player_index] = Utils.get_rand_element(available_elements)
	elif element.is_special:
		return
	else:
		_player_characters[player_index] = null
		_on_element_focused(element, inventory_player_index)
		_player_characters[player_index] = element.item

	_set_selected_element(player_index)


func _open_hero_editor_dialog(player_index: int) -> void:
	_hero_editor_parent_options.clear()
	for character in ItemService.characters:
		if not ProgressData.characters_unlocked.has(character.my_id_hash) and not DebugService.unlock_all_chars:
			continue
		if _get_item_disabled_update(character) != null:
			continue
		_hero_editor_parent_options.push_back(character)
	if _hero_editor_parent_options.empty():
		return

	_hero_editor_pending_player = player_index
	if _hero_editor_dialog != null and is_instance_valid(_hero_editor_dialog):
		_hero_editor_dialog.queue_free()

	_hero_editor_dialog = ConfirmationDialog.new()
	_hero_editor_dialog.window_title = "角色合成"
	_hero_editor_dialog.get_ok().text = "合成"
	_hero_editor_dialog.get_cancel().text = "取消"
	_hero_editor_dialog.rect_min_size = Vector2(860, 640)

	var content := VBoxContainer.new()
	content.add_constant_override("separation", 12)
	_hero_editor_dialog.add_child(content)

	var title := Label.new()
	title.text = "选择两个已解锁角色，预览头像、描述和开局选择。"
	content.add_child(title)

	var parents_row := HBoxContainer.new()
	parents_row.add_constant_override("separation", 12)
	content.add_child(parents_row)
	_hero_editor_first_preview = _create_hero_editor_preview("角色 1", Color(0.9, 0.13, 0.16), true, false)
	_hero_editor_second_preview = _create_hero_editor_preview("角色 2", Color(0.08, 0.68, 0.32), true, false)
	parents_row.add_child(_hero_editor_first_preview["panel"])
	parents_row.add_child(_hero_editor_second_preview["panel"])
	_hero_editor_first = _hero_editor_first_preview["selector"]
	_hero_editor_second = _hero_editor_second_preview["selector"]

	var fusion_row := HBoxContainer.new()
	content.add_child(fusion_row)
	_hero_editor_fusion_preview = _create_hero_editor_preview("合成角色预览", Color(0.15, 0.4, 0.98), false, true)
	fusion_row.add_child(_hero_editor_fusion_preview["panel"])

	for character in _hero_editor_parent_options:
		var character_name: String = TranslationServer.translate(character.name)
		_hero_editor_first.add_item(character_name)
		_hero_editor_second.add_item(character_name)

	_hero_editor_first.selected = 0
	_hero_editor_second.selected = 1 if _hero_editor_parent_options.size() > 1 else 0
	_hero_editor_first.connect("item_selected", self, "_on_hero_editor_source_changed")
	_hero_editor_second.connect("item_selected", self, "_on_hero_editor_source_changed")
	_hero_editor_dialog.connect("confirmed", self, "_on_hero_editor_confirmed")
	add_child(_hero_editor_dialog)
	_refresh_hero_editor_previews()
	_hero_editor_dialog.popup_centered()


func _create_hero_editor_preview(title_text: String, accent: Color, with_selector: bool, show_second_icon: bool) -> Dictionary:
	var panel := PanelContainer.new()
	panel.rect_min_size = Vector2(0, 245 if with_selector else 170)
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var panel_style := StyleBoxFlat.new()
	panel_style.bg_color = Color(0.075, 0.075, 0.075, 0.98)
	panel_style.border_color = accent
	panel_style.set_border_width_all(2)
	panel.add_stylebox_override("panel", panel_style)

	var body := VBoxContainer.new()
	body.add_constant_override("separation", 8)
	panel.add_child(body)

	var heading := Label.new()
	heading.text = title_text
	heading.modulate = accent
	heading.align = Label.ALIGN_CENTER
	body.add_child(heading)

	var selector: OptionButton = null
	if with_selector:
		selector = OptionButton.new()
		selector.rect_min_size.y = 38
		selector.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		body.add_child(selector)

	var identity := HBoxContainer.new()
	identity.add_constant_override("separation", 8)
	body.add_child(identity)
	var first_icon := TextureRect.new()
	first_icon.rect_min_size = Vector2(78, 78)
	first_icon.expand = true
	first_icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	identity.add_child(first_icon)

	var second_icon: TextureRect = null
	if show_second_icon:
		var plus := Label.new()
		plus.text = "+"
		plus.align = Label.ALIGN_CENTER
		identity.add_child(plus)
		second_icon = TextureRect.new()
		second_icon.rect_min_size = Vector2(78, 78)
		second_icon.expand = true
		second_icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		identity.add_child(second_icon)

	var name_label := Label.new()
	name_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	name_label.autowrap = true
	name_label.valign = Label.VALIGN_CENTER
	identity.add_child(name_label)

	var details := Label.new()
	details.rect_min_size.y = 82 if with_selector else 58
	details.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	details.autowrap = true
	details.valign = Label.VALIGN_TOP
	body.add_child(details)

	return {"panel": panel, "selector": selector, "first_icon": first_icon, "second_icon": second_icon, "name": name_label, "details": details}


func _on_hero_editor_source_changed(_selected_index: int) -> void:
	_refresh_hero_editor_previews()


func _refresh_hero_editor_previews() -> void:
	if _hero_editor_parent_options.empty() or _hero_editor_first == null or _hero_editor_second == null:
		return
	var first_index: int = clamp(_hero_editor_first.selected, 0, _hero_editor_parent_options.size() - 1)
	var second_index: int = clamp(_hero_editor_second.selected, 0, _hero_editor_parent_options.size() - 1)
	var first: CharacterData = _hero_editor_parent_options[first_index]
	var second: CharacterData = _hero_editor_parent_options[second_index]
	_update_hero_editor_preview(_hero_editor_first_preview, first)
	_update_hero_editor_preview(_hero_editor_second_preview, second)
	_update_hero_editor_fusion_preview(_hero_editor_fusion_preview, first, second)


func _update_hero_editor_preview(preview: Dictionary, character: CharacterData) -> void:
	preview["first_icon"].texture = character.icon
	preview["name"].text = TranslationServer.translate(character.name)
	preview["details"].text = _get_hero_editor_character_summary(character)


func _update_hero_editor_fusion_preview(preview: Dictionary, first: CharacterData, second: CharacterData) -> void:
	preview["first_icon"].texture = first.icon
	preview["second_icon"].texture = second.icon
	preview["name"].text = "%s + %s" % [TranslationServer.translate(first.name), TranslationServer.translate(second.name)]
	var lines: Array = ["双方的正负面效果合并，数值效果相加。"]
	var weapons := _get_hero_editor_resource_names(_merge_hero_editor_preview_resources(first.starting_weapons, second.starting_weapons))
	var items := _get_hero_editor_resource_names(_merge_hero_editor_preview_resources(first.starting_items, second.starting_items))
	if weapons != "":
		lines.push_back("开局武器选择：" + weapons)
	if items != "":
		lines.push_back("开局道具选择：" + items)
	preview["details"].text = PoolStringArray(lines).join("\n")


func _get_hero_editor_character_summary(character: CharacterData) -> String:
	var lines: Array = []
	var description: String = TranslationServer.translate(character.description)
	if description != "" and description != "[EMPTY]":
		lines.push_back(description)
	var weapons := _get_hero_editor_resource_names(character.starting_weapons)
	var items := _get_hero_editor_resource_names(character.starting_items)
	if weapons != "":
		lines.push_back("开局武器选择：" + weapons)
	if items != "":
		lines.push_back("开局道具选择：" + items)
	return PoolStringArray(lines).join("\n") if not lines.empty() else "无额外描述"


func _merge_hero_editor_preview_resources(first: Array, second: Array) -> Array:
	var merged: Array = []
	var seen: Dictionary = {}
	for resource in first + second:
		if resource == null or seen.has(resource.my_id_hash):
			continue
		seen[resource.my_id_hash] = true
		merged.push_back(resource)
	return merged


func _get_hero_editor_resource_names(resources: Array) -> String:
	var names: PoolStringArray = PoolStringArray()
	for resource in resources:
		if resource != null:
			names.append(TranslationServer.translate(resource.name))
	return names.join("、")

func _on_hero_editor_confirmed() -> void:
	if _hero_editor_pending_player < 0 or _hero_editor_parent_options.empty():
		return
	var first_index: int = _hero_editor_first.selected
	var second_index: int = _hero_editor_second.selected
	var first: CharacterData = _hero_editor_parent_options[first_index]
	var second: CharacterData = _hero_editor_parent_options[second_index]
	var fusion: CharacterData = HeroEditorRules.make_fusion(first, second)
	if fusion == null:
		return

	_player_characters[_hero_editor_pending_player] = fusion
	_get_panels()[_hero_editor_pending_player].set_data(fusion, _hero_editor_pending_player)
	_set_selected_element(_hero_editor_pending_player)
	_hero_editor_pending_player = -1
