extends "res://main.gd"

const HeroEditorRules = preload("res://mods-unpacked/BrotatoMod-HeroEditor/hero_editor_rules.gd")

func on_levelled_up(player_index: int) -> void :
	SoundManager.play(level_up_sound, 0, 0, true)
	var level = RunData.get_player_level(player_index)

	if RunData.get_player_effect(Keys.no_level_upgrades_hash, player_index) == 0:
		_things_to_process_player_containers[player_index].upgrades.add_element(ItemService.get_icon(Keys.icon_upgrade_to_process_hash), level)

		var upgrade_to_process = UpgradesUI.UpgradeToProcess.new()
		upgrade_to_process.level = level
		upgrade_to_process.player_index = player_index
		_upgrades_to_process[player_index].push_back(upgrade_to_process)

	_players_ui[player_index].update_level_label()

	RunData.add_stat(Keys.stat_max_hp_hash, 1, player_index)
	RunData.add_meca_parts(RunData.get_player_effect(Keys.meca_parts_on_level_up_hash, player_index), player_index)

	for stat_level_up in RunData.get_player_effect(Keys.stats_on_level_up_hash, player_index):
		assert (stat_level_up[0] is int)
		RunData.add_stat(stat_level_up[0], stat_level_up[1], player_index)

		if stat_level_up[0] == Keys.stat_lifesteal_hash:
			RunData.add_tracked_value(player_index, Keys.item_decomposing_flesh_hash, stat_level_up[1])
		elif stat_level_up[0] == Keys.stat_hp_regeneration_hash:
			RunData.add_tracked_value(player_index, Keys.item_baby_squid_hash, stat_level_up[1])
		elif stat_level_up[0] == Keys.stat_curse_hash:
			var val = stat_level_up[1]

			
			

			if HeroEditorRules.has_origin(RunData.get_player_character(player_index), "character_creature"):
				val -= 1

			if val > 0:
				RunData.add_tracked_value(player_index, Keys.item_barnacle_hash, 1)

func clean_up_room() -> void :
	_set_run_states()
	_stop_ambient()

	_ui_dim_screen.dim()
	_wave_timer.stop()
	EntityService.stop_enemy_time_slow()
	for timer in _half_second_timers.get_children():
		if timer is Timer:
			timer.stop()


	_enemy_projectiles.queue_free()

	if _is_run_lost:
		_end_wave_timer.wait_time = 0.5
		DebugService.log_data("is_run_lost")

	elif _is_run_won:
		_end_wave_timer.wait_time = 4
		RunData.apply_run_won()

	if _is_wave_failed:
		MusicManager.tween( - 20)
		if RunData.current_wave > 1:
			_end_wave_timer.wait_time = 0.5

	_end_wave_timer.start()

	if RunData.current_wave % 10 == 0 and RunData.current_wave >= 10:
		RunData.init_elites_spawn(RunData.current_wave + 10, 0.0)
		RunData.init_events_nightmare(RunData.current_wave + 10)


	if RunData.is_endless_run:

		DebugService.log_data("is_endless_run")

		if RunData.current_wave >= 20:
			for player_index in RunData.get_player_count():
				var character_difficulty = ProgressData.get_character_difficulty_info(RunData.players_data[player_index].current_character.my_id_hash, RunData.current_zone)

				character_difficulty.max_endless_wave_beaten.set_info(
					RunData.current_difficulty, 
					RunData.current_wave, 
					RunData.current_run_accessibility_settings.health, 
					RunData.current_run_accessibility_settings.damage, 
					RunData.current_run_accessibility_settings.speed, 
					RunData.retries, 
					0 if not RunData.is_ban_active_in_current_run() else RunData.get_used_ban_count(), 
					RunData.constant_projectile, 
					RunData.is_coop_run, 
					true
				)

	ProgressData.save()

	SoundManager.play(Utils.get_rand_element(end_wave_sounds))
	_cleaning_up = true
	_effects_manager.clean_up_room()
	_floating_text_manager.clean_up_room()

	DebugService.log_data("attract bonus_gold and consumables...")
	if _active_golds.size() > 0:
		var attracted_by = null

		_ui_bonus_gold.show()
		attracted_by = _gold_bag

		for player in _players:
			player.disable_gold_pickup()

		var nb_builders = 0
		var indexes_builder = []

		for player_id in RunData.players_data.size():
			if HeroEditorRules.has_origin(RunData.get_player_character(player_id), "character_builder"):
				nb_builders += 1
				indexes_builder.push_back(player_id)

		if nb_builders > 0:
			for structure in _entity_spawner.structures:
				if structure is BuilderTurret:
					override_gold_bag_pos = structure.global_position
					var _e = RunData.connect("bonus_gold_converted", structure, "on_bonus_gold_converted")
					_e = structure.connect("stat_added", _floating_text_manager, "on_turret_stat_added")
					structure.main_ref = self

		if ProgressData.settings.optimize_end_waves:
			var bonus_gold_value = 0
			var player_count = RunData.get_player_count()
			for i in _active_golds.size():
				var gold = _active_golds[i]
				var player_index = i % player_count
				var boost = RunData.apply_common_gold_pickup_effects(gold.value, player_index)
				bonus_gold_value += gold.value * boost
				gold.boosted *= boost
				gold.visible = false

			RunData.add_bonus_gold(bonus_gold_value)
		else:
			for gold in _active_golds:
				gold.collision_layer = Utils.BONUS_GOLD_BIT
				gold.attracted_by = attracted_by
				gold.set_physics_process(true)

	var live_players: = _get_shuffled_live_players()
	if not live_players.empty():
		var fruit_receivers: = []
		for player in live_players:
			if RunData.get_player_effect(Keys.no_fruit_attracted_end_of_wave_hash, player.player_index) == 0:
				fruit_receivers.append(player)

		var nb_fruits_attracted: = 0
		var evolution_consumables_received: = {}
		for i in _consumables.size():
			var player = live_players[i % live_players.size()]
			var consumable: Consumable = _consumables[i]
			if not consumable.should_be_picked_up_at_end_of_wave():
				continue

			var consumable_id_hash: int = consumable.consumable_data.my_id_hash
			if consumable_id_hash == Keys.consumable_mutation_fruit_hash or consumable_id_hash == Keys.consumable_meca_parts_hash:
				player = _get_least_served_player_able_to_pick_up(consumable, live_players, evolution_consumables_received)
				if player == null:
					continue
				evolution_consumables_received[consumable_id_hash][player.player_index] += 1
			elif consumable_id_hash == Keys.consumable_fruit_hash and RunData.get_player_effect(Keys.no_fruit_attracted_end_of_wave_hash, player.player_index) != 0:
				if fruit_receivers.empty():
					continue
				player = fruit_receivers[nb_fruits_attracted % fruit_receivers.size()]
				nb_fruits_attracted += 1

			consumable.attracted_by = player
			consumable.set_physics_process(true)

	DebugService.log_data("clean_up other objects...")
	_entity_spawner.clean_up_room()
	_wave_manager.clean_up_room()

	for player in _players:
		if is_instance_valid(player):
			player.on_room_cleanup()

	
	if _is_run_won:
		for player_index in RunData.get_player_count():
			var player: Player = _players[player_index]
			player.won()
		yield(_players[0], "run_won_screen")
		SoundManager.play(Utils.get_rand_element(run_won_sounds), - 5, 0, true)

	DebugService.log_data("start wave_cleared_label...")
	_wave_cleared_label.start(_is_wave_failed, _is_run_lost, _is_run_won)
	DebugService.log_data("wave_cleared_label started...")
