extends "res://singletons/item_service.gd"

const HeroEditorRules = preload("res://mods-unpacked/BrotatoMod-HeroEditor/hero_editor_rules.gd")

func get_icon_for_duplicate_shop_item(character: CharacterData, player_items: Array, player_weapons: Array, shop_item: ItemParentData, player_index: int) -> Texture:

	if character == null or shop_item == null:
		return null

	var copies = 0
	var same_tier_copies = 0
	var fairy_data = null
	var has_free_weapon_slot = false

	if shop_item is ItemData:
		for item in player_items:
			if item.my_id_hash == shop_item.my_id_hash:
				copies += 1

			if item.my_id_hash == Keys.item_fairy_hash:
				fairy_data = item

	if shop_item is WeaponData:
		has_free_weapon_slot = RunData.has_weapon_slot_available(shop_item, player_index)
		for weapon in player_weapons:
			if weapon.weapon_id_hash == shop_item.weapon_id_hash:
				copies += 1
			if weapon.my_id_hash == shop_item.my_id_hash:
				same_tier_copies += 1

	var already_has_it = copies > 0
	var weapon_is_max_tier = shop_item.tier == Tier.LEGENDARY
	var would_combine_on_buy = not weapon_is_max_tier and not has_free_weapon_slot and same_tier_copies >= 1

	var renegade_cond = HeroEditorRules.has_origin(character, "character_renegade") and shop_item is ItemData and shop_item.tier == Tier.COMMON and not already_has_it
	var curious_cond_neg = HeroEditorRules.has_origin(character, "character_curious") and already_has_it and ( not (shop_item is WeaponData) or not would_combine_on_buy)
	var curious_cond_pos = HeroEditorRules.has_origin(character, "character_curious") and shop_item is ItemData and not already_has_it
	var king_cond_pos = HeroEditorRules.has_origin(character, "character_king") and ((shop_item is ItemData and not already_has_it) or shop_item is WeaponData) and shop_item.tier == Tier.LEGENDARY
	var king_cond_neg = HeroEditorRules.has_origin(character, "character_king") and ((shop_item is ItemData and not already_has_it) or shop_item is WeaponData) and shop_item.tier == Tier.COMMON and not would_combine_on_buy

	var fairy_cond_pos = fairy_data and shop_item.tier == Tier.COMMON and not already_has_it
	var fairy_cond_neg = fairy_data and shop_item.tier == Tier.LEGENDARY and not already_has_it

	if curious_cond_pos:
		return get_icon(Keys.generate_hash("icon_curious_happy")).get_data()
	elif curious_cond_neg:
		return get_icon(Keys.generate_hash("icon_curious_sad")).get_data()
	elif king_cond_pos:
		return get_icon(Keys.generate_hash("icon_king_happy")).get_data()
	elif king_cond_neg:
		return get_icon(Keys.generate_hash("icon_king_sad")).get_data()
	elif fairy_cond_pos:
		return get_icon(Keys.generate_hash("icon_fairy_happy")).get_data()
	elif fairy_cond_neg:
		return get_icon(Keys.generate_hash("icon_fairy_sad")).get_data()
	elif renegade_cond:
		return character.get_icon().get_data()

	return null

