extends "res://ui/menus/shop/shop_item.gd"

const HeroEditorRules = preload("res://mods-unpacked/BrotatoMod-HeroEditor/hero_editor_rules.gd")

func manage_ban_button_visibility() -> void :
	if not ChallengeService.is_challenge_completed(ChallengeService.chal_banned_items_hash) or not RunData.is_ban_active_in_current_run() or item_data is WeaponData:
		_ban_button.disable()
		_ban_button.hide()
		return

	if item_data != null and item_data.my_id_hash == Keys.item_bait_hash:
		if HeroEditorRules.has_origin(RunData.players_data[player_index].current_character, "character_fisherman"):
			_ban_button.disable()
			_ban_button.hide()
			return

	var remaining_ban_token = RunData.players_data[player_index].remaining_ban_token
	_ban_button.text = Text.text("BAN_SHOP", [str(remaining_ban_token)])
	if remaining_ban_token > 0:
		if not RunData.is_coop_run:
			_ban_button.show()
		_ban_button.activate()
	else:
		_ban_button.disable()
		_ban_button.hide()
