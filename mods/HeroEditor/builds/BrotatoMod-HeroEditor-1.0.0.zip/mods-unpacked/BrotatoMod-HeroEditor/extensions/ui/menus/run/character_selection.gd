extends "res://ui/menus/run/character_selection.gd"

const HeroEditorRules = preload("res://mods-unpacked/BrotatoMod-HeroEditor/hero_editor_rules.gd")

var _hero_editor_dialog: ConfirmationDialog
var _hero_editor_first: OptionButton
var _hero_editor_second: OptionButton
var _hero_editor_parent_options: Array = []
var _hero_editor_pending_player: int = -1


func _get_all_possible_elements(player_index: int) -> Array:
	var elements: Array = ._get_all_possible_elements(player_index)
	var editor_row: CharacterData = HeroEditorRules.make_editor_row()
	if editor_row != null:
		elements.push_back(editor_row)
	return elements


func _get_unlocked_elements(player_index: int) -> Array:
	var unlocked: Array = ._get_unlocked_elements(player_index).duplicate()
	var editor_hash: int = Keys.generate_hash("character_hero_editor")
	if not unlocked.has(editor_hash):
		unlocked.push_back(editor_hash)
	return unlocked


func _on_element_pressed(element: InventoryElement, inventory_player_index: int) -> void:
	var player_index: int = FocusEmulatorSignal.get_player_index(element)
	if player_index < 0:
		return

	if element.item is CharacterData and HeroEditorRules.is_editor_row(element.item):
		_open_hero_editor_dialog(player_index)
		return

	if element.is_random:
		var available_elements: Array = []
		for candidate in displayed_elements[0]:
			if candidate is CharacterData and HeroEditorRules.is_editor_row(candidate):
				continue
			if not candidate.is_locked and _get_item_disabled_update(candidate) == null:
				available_elements.push_back(candidate)
		_player_characters[player_index] = Utils.get_rand_element(available_elements)
	elif element.is_special:
		return
	else:
		_player_characters[player_index] = null
		_on_element_focused(element, inventory_player_index)
		_player_characters[player_index] = element.item

	_set_selected_element(player_index)


func _open_hero_editor_dialog(player_index: int) -> void:
	_hero_editor_parent_options.clear()
	for character in ItemService.characters:
		if not ProgressData.characters_unlocked.has(character.my_id_hash) and not DebugService.unlock_all_chars:
			continue
		if _get_item_disabled_update(character) != null:
			continue
		_hero_editor_parent_options.push_back(character)
	if _hero_editor_parent_options.empty():
		return

	_hero_editor_pending_player = player_index
	if _hero_editor_dialog != null and is_instance_valid(_hero_editor_dialog):
		_hero_editor_dialog.queue_free()

	_hero_editor_dialog = ConfirmationDialog.new()
	_hero_editor_dialog.window_title = "角色合成"
	_hero_editor_dialog.get_ok().text = "合成"
	_hero_editor_dialog.get_cancel().text = "取消"
	_hero_editor_dialog.rect_min_size = Vector2(540, 260)
	var content := VBoxContainer.new()
	content.add_constant_override("separation", 12)
	_hero_editor_dialog.add_child(content)

	var title := Label.new()
	title.text = "选择两个已解锁角色，合成结果仅对本局有效。"
	content.add_child(title)

	var first_label := Label.new()
	first_label.text = "第一个角色"
	content.add_child(first_label)
	_hero_editor_first = OptionButton.new()
	content.add_child(_hero_editor_first)

	var second_label := Label.new()
	second_label.text = "第二个角色"
	content.add_child(second_label)
	_hero_editor_second = OptionButton.new()
	content.add_child(_hero_editor_second)

	for character in _hero_editor_parent_options:
		var character_name: String = TranslationServer.translate(character.name)
		_hero_editor_first.add_item(character_name)
		_hero_editor_first.set_item_metadata(_hero_editor_first.get_item_count() - 1, character)
		_hero_editor_second.add_item(character_name)
		_hero_editor_second.set_item_metadata(_hero_editor_second.get_item_count() - 1, character)

	_hero_editor_first.selected = 0
	_hero_editor_second.selected = 1 if _hero_editor_parent_options.size() > 1 else 0
	_hero_editor_dialog.connect("confirmed", self, "_on_hero_editor_confirmed")
	add_child(_hero_editor_dialog)
	_hero_editor_dialog.popup_centered()


func _on_hero_editor_confirmed() -> void:
	if _hero_editor_pending_player < 0 or _hero_editor_parent_options.empty():
		return
	var first_index: int = _hero_editor_first.selected
	var second_index: int = _hero_editor_second.selected
	var first: CharacterData = _hero_editor_first.get_item_metadata(first_index)
	var second: CharacterData = _hero_editor_second.get_item_metadata(second_index)
	var fusion: CharacterData = HeroEditorRules.make_fusion(first, second)
	if fusion == null:
		return

	_player_characters[_hero_editor_pending_player] = fusion
	_get_panels()[_hero_editor_pending_player].set_data(fusion, _hero_editor_pending_player)
	_set_selected_element(_hero_editor_pending_player)
	_hero_editor_pending_player = -1